import thunk from 'redux-thunk';
import router from './router';

export default [
  thunk,
  router,
];
