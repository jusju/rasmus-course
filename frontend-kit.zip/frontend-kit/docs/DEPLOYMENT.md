# Deployment

See https://github.com/facebookincubator/create-react-app/blob/master/packages/react-scripts/template/README.md#deployment
